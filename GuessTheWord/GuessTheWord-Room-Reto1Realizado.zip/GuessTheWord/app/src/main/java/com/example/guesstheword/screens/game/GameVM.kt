package com.example.guesstheword.screens.game

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.example.guesstheword.datamodel.Word
import com.example.guesstheword.dependencies.MyApplication
import com.example.guesstheword.repositories.GamesRepository
import com.example.guesstheword.repositories.WordsRepository
import com.example.guesstheword.utils.MyTimer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor

class GameVM(
    val wordsRepository: WordsRepository,
    val gamesRepository: GamesRepository
    ) : ViewModel() {

    private val _uiState : MutableStateFlow<GameUiState> = MutableStateFlow(GameUiState())
    val uiState : StateFlow<GameUiState> = _uiState.asStateFlow()


    init {
        //inicializa las palabras.
        viewModelScope.launch {
            //numero de palabras que toma
            val words = wordsRepository.getSomeRandomWords(NUM_WORDS)
            if(words.size > 1) { //si hay más de una palabra.
                _uiState.update { currentSate ->
                    currentSate.copy(
                        word = words[0],
                        score = 0,
                        wordList = words.subList(1,words.size)
                    )
                }
            } else if(words.size > 0) { //tiene una sola palabra.
                _uiState.update { currentSate ->
                    currentSate.copy(
                        word = words[0],
                        score = 0,
                        wordList = emptyList()
                    )
                }
            } else { //no tiene palabras, levanta bandera para desactivar botones.
                _uiState.update { currentSate ->
                    currentSate.copy(
                        word = null,
                        wordList = emptyList(),
                        finalWord = true,
                        message = "No hay palabras."
                    )
                }
            }
        }

        //inicializa el temporizador.
        viewModelScope.launch {
            MyTimer(10f,0.5f,500).timer.filter {
                it - floor(it) == 0f
            }.collect {
                _uiState.update { currentState ->
                    currentState.copy(
                        time = it
                    )
                }
            }
        }
    }

    //Función que toma una nueva palabra e incrementa o decrementa la puntuación.
    fun nextWord(acierto : Boolean) {
        val inc = if (acierto) 1 else -1
        if(uiState.value.wordList.isNotEmpty()) {
            _uiState.update { currentState ->
                currentState.copy(
                    word = currentState.wordList[0],
                    score = currentState.score+inc,
                    wordList = currentState.wordList.subList(1,currentState.wordList.size),
                    rightWords = if (acierto)
                        currentState.rightWords.plus(currentState.word!!.title)
                    else
                        currentState.rightWords,
                    wrongWords = if (!acierto)
                        currentState.wrongWords.plus(currentState.word!!.title)
                    else
                        currentState.wrongWords
                    )
            }
        } else { //ultima palabra
            _uiState.update { currentState ->
                currentState.copy(
                    word = null,
                    score = currentState.score+inc,
                    wordList = emptyList(),
                    rightWords = if (acierto) currentState.rightWords.plus(currentState.word!!.title)
                    else
                        currentState.rightWords,
                    wrongWords = if (!acierto)
                        currentState.wrongWords.plus(currentState.word!!.title)
                    else
                        currentState.wrongWords,
                    finalWord = true
                )
            }
        }
        //mostrar mensaje por pantalla cuando la puntuación llegue a 10
        if(uiState.value.score == 10 && inc == 1)
            _uiState.update { currenState ->
                currenState.copy(
                    message = "Good score!"
                )
            }
    }

    override fun onCleared() {
        super.onCleared()
        Log.i("GameViewModel", "GameViewModel destruido!")
    }

    fun messageShown() {
        _uiState.update { currenState ->
            currenState.copy(
                message = null
            )
        }
    }

    fun disableButtonsCompleted() {
        _uiState.update {
            it.copy(
                finalWord = false
            )
        }
    }

    companion object {
        //número máximo de palabras del juego.
        val NUM_WORDS = 10

        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(
                modelClass: Class<T>,
                extras: CreationExtras
            ): T {
                // Get the Application object from extras
                val application = checkNotNull(extras[APPLICATION_KEY])

                return GameVM(
                    (application as MyApplication).appcontainer.wordsRepository,
                    (application).appcontainer.gamesRepository
                ) as T
            }
        }
    }

}