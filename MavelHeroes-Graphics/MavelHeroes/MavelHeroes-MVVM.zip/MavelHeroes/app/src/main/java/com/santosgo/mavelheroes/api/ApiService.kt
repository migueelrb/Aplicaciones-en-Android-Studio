package com.santosgo.mavelheroes.api

interface ApiService {
}