package com.santosgo.mavelheroes.data

import android.os.Parcel
import android.os.Parcelable

//Clase con los objetos del RecyclerView.
data class Hero(
    val name : String,
    val power : Int,
    val intelligence : Int,
    val photo : String,
    val description : String
)