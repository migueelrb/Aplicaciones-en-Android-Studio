package com.example.guesstheword.screens.game

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.CreationExtras
import com.example.guesstheword.dependencies.MyApplication
import com.example.guesstheword.repository.WordsRepository

class GameVM(val wordsRepository: WordsRepository) : ViewModel() {

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(
                modelClass: Class<T>,
                extras: CreationExtras
            ): T {
                // Get the Application object from extras
                val application = checkNotNull(extras[APPLICATION_KEY])

                return GameVM(
                    (application as MyApplication).appcontainer.wordsRepository,
                ) as T
            }
        }
    }

    private var _score : Int = 0
    val score get() = _score

    private var _word : String = ""
    val word get() = _word

    private lateinit var _wordList : MutableList<String>
    val wordList get() = _wordList

    init {
        Log.i("GameViewModel", "GameViewModel creado!")
        _wordList = wordsRepository.resetList()
        nextWord()
        _score = 0
    }

    override fun onCleared() {
        super.onCleared()
        Log.i("GameViewModel", "GameViewModel destruido!")
    }


    fun onSkip() {
        _score--
        nextWord()
    }

    fun onCorrect() {
        _score++
        nextWord()
    }

    fun nextWord() {
        if (!wordList.isEmpty()) {
            //Select and remove a word from the list
            _word = wordList.removeAt(0)
        } else {
            _word = "No more words."
        }
    }
}