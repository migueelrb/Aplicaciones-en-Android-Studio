package com.example.guesstheword.dependencies

import android.app.Application

class MyApplication : Application() {

    //contenedor de dependencias manuales.
    private val _appContainer = Appcontainer()
    val appcontainer get() = _appContainer
}