package com.example.guesstheword.dependencies

import com.example.guesstheword.repository.WordsRepository

class Appcontainer {

    //Repositorio de palabras.
    private val _wordsRepository : WordsRepository = WordsRepository()
    val wordsRepository get() = _wordsRepository

    //Factory de ViewModel de Game.
    private val _gameVMFactory = GameVMFactory(wordsRepository)
    val gameVMFactory get() = _gameVMFactory

}
