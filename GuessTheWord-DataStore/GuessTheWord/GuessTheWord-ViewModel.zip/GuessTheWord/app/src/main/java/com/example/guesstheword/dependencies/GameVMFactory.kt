package com.example.guesstheword.dependencies

import com.example.guesstheword.repository.WordsRepository
import com.example.guesstheword.screens.game.GameVM

class GameVMFactory(private val wordsRepository: WordsRepository) : Factory<GameVM> {

    var gameVM : GameVM? = null
    override fun create() : GameVM {
        if(gameVM == null)
            gameVM = GameVM(wordsRepository)
        return gameVM!!
    }
}